package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.model.dr_Customers;

@Repository
public class AdminDaoImpl implements AdminDao {
	@PersistenceContext
	@Autowired
	private EntityManager entitymanager;
	

	
	
	@Override
	public List<dr_Customers> readAllUsers() {
		String jpql="select d From dr_Customers d";
		TypedQuery<dr_Customers> tquery=entitymanager.createQuery(jpql,dr_Customers.class);
		List<dr_Customers>list=tquery.getResultList();
		return list;
		
	}




	@Override
	public List<dr_Customers> validateUsers() {
		String jpql="select d From dr_Customers d where d.status=1";
		
	
		TypedQuery<dr_Customers> tquery=entitymanager.createQuery(jpql,dr_Customers.class);
	
		List<dr_Customers>list=tquery.getResultList();
		return list;
	}
	

}
