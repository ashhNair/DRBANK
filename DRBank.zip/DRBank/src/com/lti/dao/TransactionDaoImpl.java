package com.lti.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.lti.model.Account_details;
import com.lti.model.Drtransactions;
import com.lti.model.Internet_banking;

@Repository
public class TransactionDaoImpl implements TransactionDao {

	@Autowired
	private Internet_banking ib;
	
	@Autowired
	private Account_details acc;
	@Autowired
	private Account_details acc1;
	@Autowired
	private Drtransactions transaction;

	
	@PersistenceContext
	private EntityManager em;
	
	@Override
	public boolean validatepin(int tpin, String username) {
		ib=em.find(Internet_banking.class, username);
		int cpin=ib.getPin();
		if(cpin==tpin)
		{
			return true;
		}
		return false;
	}

	@Override
	public Drtransactions performtransaction(double amount, long accno, long benaccno,String remark, String type) {
		try{
			acc=em.find(Account_details.class,accno);
		
		double balance=acc.getBalance()-amount;
		acc.setBalance(balance);
		em.merge(acc);
		acc1=em.find(Account_details.class,benaccno);
		if(acc1!=null)
		{
			balance=acc1.getBalance()+amount;
			acc1.setBalance(balance);
			em.merge(acc1);
		}
		
		transaction.setAccNo(accno);
		transaction.setAmount(amount);
		transaction.setbAccNo(benaccno);
		transaction.setRemarks(remark);
		transaction.setTransactionType(type);
		transaction.setTransactionStatus(0);
		java.sql.Date date = new java.sql.Date(new java.util.Date().getTime());
		transaction.setTransactionDate(date);
		em.persist(transaction);
		if(transaction==null)
		{
			throw new Exception();
		}
		}catch(Exception e)
		{
			transaction.setTransactionStatus(1);
			em.merge(transaction);
		}
		return transaction;
	}

}
