package com.lti.dao;

import java.util.List;

import com.lti.model.dr_Customers;

public interface AdminDao {

	public List<dr_Customers> readAllUsers();
	public List<dr_Customers> validateUsers();

}
