package com.lti.model;


import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
@Component
@Entity
@Table(name="DR_TRANSACTION")
@SequenceGenerator(name="drbeneficiaryseq" , sequenceName="DR_TRANSACTIONID_SEQ" , initialValue=100 , allocationSize=1)
public class Drtransactions {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="drbeneficiaryseq")
	@Column(name="TRANSACTION_ID")
	private long transactionID;
	@Column(name="TRANSACTION_STATUS")
	private int transactionStatus;
	@Column(name="ACC_NO")
	private long accNo;
	@Column(name="BENEFICIARY_ACC_NO")
	private long bAccNo;
	@Column(name="TRANSACTION_TYPE")
	private String transactionType;
	@Column(name="REMARKS")
	private String remarks;
	@Column(name="TRANSACTION_DATE")
	private Date transactionDate;
	@Column(name="AMOUNT")
	private double amount;
	
	public Drtransactions(){}
	
	public Drtransactions(long transactionID, int transactionStatus, long accNo, long bAccNo, String transactionType,
			String remarks, Date transactionDate, double amount) {
		super();
		this.transactionID = transactionID;
		this.transactionStatus = transactionStatus;
		this.accNo = accNo;
		this.bAccNo = bAccNo;
		this.transactionType = transactionType;
		this.remarks = remarks;
		this.transactionDate = transactionDate;
		this.amount = amount;
	}

	public long getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(long transactionID) {
		this.transactionID = transactionID;
	}

	public int getTransactionStatus() {
		return transactionStatus;
	}

	public void setTransactionStatus(int transactionStatus) {
		this.transactionStatus = transactionStatus;
	}

	public long getAccNo() {
		return accNo;
	}

	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}

	public long getbAccNo() {
		return bAccNo;
	}

	public void setbAccNo(long bAccNo) {
		this.bAccNo = bAccNo;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Date getTransactionDate() {
		return transactionDate;
	}

	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

}
