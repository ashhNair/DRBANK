package com.lti.service;

public interface LoginService {
public boolean readUserLogin(String username,String password);
public void CreateUserIb(String username,double accno,String password,int pin);
public boolean readAdminLogin(String username,String password);
}
