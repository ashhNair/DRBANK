package com.lti.service;

import java.util.List;

import com.lti.model.Drtransactions;

public interface TransactionService {

	public boolean validatepin(int tpin, String username);

	public Drtransactions performtransaction(double amount, long benaccno, long accno, String remark, String type);

}
