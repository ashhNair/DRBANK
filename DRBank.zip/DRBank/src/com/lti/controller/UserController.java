package com.lti.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.lti.model.Account_details;
import com.lti.model.Beneficiary;
import com.lti.model.dr_Customers;
import com.lti.service.UserService;

@Controller
public class UserController {
	@Autowired
	private UserService userservice;
	@Autowired
	private dr_Customers customer;
	
	@RequestMapping(path="checkusername.do")
	@ResponseBody
	public String CheckUsernameAvail(@RequestParam("username") String username,HttpServletResponse response)
	{
		response.setContentType("text/plain");
		response.setCharacterEncoding("UTF-8");
		boolean result = userservice.CheckUsername(username);
		if(result)
		{
			return "";
		}
		return "False";
	}
	
	@RequestMapping(path="checkacc.do")
	@ResponseBody
	public String CheckAccnumber(@RequestParam("accountnumber") long accno,HttpServletResponse response)
	{
		response.setContentType("text/plain");
		response.setCharacterEncoding("UTF-8");
		boolean result = userservice.CheckAccno(accno);
		if(result)
		{
			return "";
		}
		return "False";
	}
	@RequestMapping(path="registerib.do")
	public String Addaccount(@RequestParam("account_number") long accno,@RequestParam("username") String username,@RequestParam("set_password") String password,@RequestParam("Set_Pin") int pin)
	{
		userservice.adduser(accno, username, password, pin);
		return "redirect:loginpage";
	}
	
	@RequestMapping(path = "addbeneficiarypage")
	public String AdminloginPage() {
		return "AddBeneficiary";
	}
	
	@RequestMapping(path="addbeneficiary")
	public String addbeneficiary(@RequestParam("beneficiary_name") String bname, @RequestParam("beneficiary_account_number") long baccno,@RequestParam("IFSC") String bIFSC, @RequestParam("nickname") String nickname,HttpServletRequest request,HttpSession session)
	{
		request.getSession();
		String username=(String) session.getAttribute("username");
		userservice.readBeneficiary(bname, baccno, bIFSC, nickname, username);
		return "SuccessfullBeneficiary";
	}
	
	@RequestMapping(path="createaccountpage")
	public String CreateAccountPage()
	{
		return "OpenAccount";
	}
	@RequestMapping(path="CreateAccount", method = RequestMethod.POST)
	public String CreateAccount(@RequestParam("firstname")String firstname,@RequestParam("lastname")String lastname,@RequestParam("middlename")String middlename,
			@RequestParam("email")String email,@RequestParam("dob")String dateofbirth,@RequestParam("mobile")long mobile,@RequestParam("gender")String gender,
			@RequestParam("Paddress")String PERMANENT_ADDRESS,@RequestParam("Raddress")String CORRESPONDING_ADDRESS,@RequestParam("aadhar")String aadhar_no,
			@RequestParam("account_type")String acc_type,@RequestParam("BranchName")String IFSC){
			
		customer.setFirstname(firstname);
		customer.setLastname(lastname);
		customer.setMiddlename(middlename);
		customer.setEmail(email);
		customer.setDateofbirth(dateofbirth);
		customer.setMobile(mobile);
		customer.setGender(gender);
		customer.setPERMANENT_ADDRESS(PERMANENT_ADDRESS);
		customer.setCORRESPONDING_ADDRESS(CORRESPONDING_ADDRESS);
		customer.setAadhar_no(aadhar_no);
		customer.setAcc_type(acc_type);
		customer.setIFSC(IFSC);
		customer.setAadhar_path("");
		customer.setPhoto_path("");
		customer.setReason("");
		customer.setStatus("1");
		boolean result = userservice.addCustomer(customer);
		if(result){
			return "Successfull";
		}
		return "redirect: CreateAccount";
	}
	
	
	//NEFT
	
	@RequestMapping(path="transfer")
	public String Transfer()
	{
		return "Transfer";
	}
	
	@RequestMapping(path="selectbeneficiaryNEFT")
	public String selectbeneficiaryNEFT()
	{
		return "redirect:ViewBeneficiaryNEFT";
	}
	//ViewBeneficiary
	@RequestMapping(path="ViewBeneficiaryNEFT", method=RequestMethod.GET)
	public String viewBeneficiaryNEFT(Model model, HttpServletRequest request,HttpSession session){
		String username=(String) session.getAttribute("username");
		List<Beneficiary> list = userservice.findAllBeneficiary(username);
		model.addAttribute("BeneficiaryList", list);
		return "SelectBeneficiaryNEFT";
	}
	@RequestMapping(path="performneft", method=RequestMethod.POST)
	public String neftPage(@RequestParam("beneficiaryid") long beneficiaryid,Model model, HttpServletRequest request,HttpSession session)
	{
		Beneficiary ben = userservice.getbeneficiary(beneficiaryid);
		long custid=ben.getCustomer_Id();
		session.setAttribute("type", "NEFT");
		Account_details acc=userservice.getAccount(custid);
		model.addAttribute("account", acc);
		model.addAttribute("beneficiary", ben);
		return "NEFT";
	}
	
	//RTGS
	
	@RequestMapping(path="selectbeneficiaryRTGS")
	public String selectbeneficiaryRTGS()
	{
		return "redirect:ViewBeneficiaryRTGS";
	}
	//ViewBeneficiary
	@RequestMapping(path="ViewBeneficiaryRTGS", method=RequestMethod.GET)
	public String viewBeneficiaryRTGS(Model model, HttpServletRequest request,HttpSession session){
		String username=(String) session.getAttribute("username");
		List<Beneficiary> list = userservice.findAllBeneficiary(username);
		model.addAttribute("BeneficiaryList", list);
		return "SelectBeneficiaryRTGS";
	}
	
	@RequestMapping(path="performRTGS", method=RequestMethod.POST)
	public String RTGSPage(@RequestParam("beneficiaryid") long beneficiaryid,Model model, HttpServletRequest request,HttpSession session)
	{
		Beneficiary ben = userservice.getbeneficiary(beneficiaryid);
		long custid=ben.getCustomer_Id();
		session.setAttribute("type", "RTGS");
		Account_details acc=userservice.getAccount(custid);
		model.addAttribute("account", acc);
		model.addAttribute("beneficiary", ben);
		return "RTGS";
	}
}
